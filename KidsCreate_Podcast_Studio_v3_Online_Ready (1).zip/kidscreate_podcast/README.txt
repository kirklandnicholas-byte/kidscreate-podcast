KidsCreate Podcast Studio v3 — Collapsible Creative Coach

Open index.html to use the offline podcast planner and guidance. For microphone recording, use HTTPS or localhost (for example Netlify), and allow the microphone when prompted.

CHANGES
- Creative Coach is a compact, closed-by-default "Need help?" disclosure on every stage.
- Sentence frames no longer merge an entire student topic sentence into a question.
- Optional real online AI support is available via a server-side Netlify Function.

PUBLISH ONLINE (website)
1. Create a PRIVATE test site on Netlify (https://app.netlify.com/).
2. Import this folder via Git repository and set the publish directory to the project root.
3. Deploy. The Podcast Studio is now on an HTTPS web address. The offline Creative Coach works without any API key.
4. Optional ONLINE AI: in Netlify Site Configuration > Environment Variables, add OPENAI_API_KEY (secret, server-only), then redeploy. Do not put the secret in the HTML. The 'Use online AI' checkbox then enables responses.
5. Configure domain access / identity protection appropriate for an invitation-only student pilot BEFORE giving anyone the URL. Do not publish real student recordings or data on a public site.

LIMITATIONS / PRIVACY
- No hosting has been performed by this ZIP; deployment requires site owner access.
- Online AI sends only the entered question, age group, stage and short topic label to the AI provider. Do not include identifying information. No raw audio is sent.
- This prototype has no authentication, server-side consent, robust rate limiting, abuse monitoring, or publication moderation. The optional AI endpoint should not be made openly accessible to children until these are added.
- Drafts and recordings are local to the browser/device. Different devices do not share drafts.
- Online AI requires an API account, configured secret and API usage charges.
- Some browsers may have recording/export limitations. Test student devices before use.
